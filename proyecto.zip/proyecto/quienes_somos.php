<?php include('views/header.php'); ?>
<h2>Quiénes Somos</h2>
<p>Bienvenido a nuestra empresa de electrodomésticos, aquí encontraras los mejores productos...</p>
<?php include('views/footer.php'); ?>
