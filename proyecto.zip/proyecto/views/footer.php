</main>
<footer>
    <p>&copy; 2024 TechServer Solutions. Todos los derechos reservados.</p>
</footer>
</body>
</html>
